/* Copyright (C) YOOtheme GmbH, http://www.gnu.org/licenses/gpl.html GNU/GPL */

jQuery(function($) {

    var config = $('html').data('config') || {};

    // Social buttons
    $('article[data-permalink]').socialButtons(config);

});


jQuery(function($){
	$(window).on('scroll', function(){
		if( $(window).scrollTop()>50 ){
			$('.tm-headerbar-bg').addClass('menu-fixed');
		} else {
			$('.tm-headerbar-bg').removeClass('menu-fixed');
		}
	});

	
	
});

//Parallax//////////////////////////////
!function(a){var b=a(window),c=b.height();b.resize(function(){c=b.height()}),a.fn.parallax=function(d,e,f){function k(){var f=b.scrollTop();g.each(function(){var b=a(this),j=b.offset().top,k=h(b);f>j+k||j>f+c||g.css("backgroundPosition",d+" "+Math.round((i-f)*e)+"px")})}var h,i,g=a(this);g.each(function(){i=g.offset().top}),h=f?function(a){return a.outerHeight(!0)}:function(a){return a.height()},(arguments.length<1||null===d)&&(d="50%"),(arguments.length<2||null===e)&&(e=.1),(arguments.length<3||null===f)&&(f=!0),b.bind("scroll",k).resize(k),k()}}(jQuery);
jQuery(document).ready(function($) {
$(" .tm-block-bottom-a").addClass("fixed-background").parallax("55%", 0.7);

 //To top scroller//////////////////////////
    jQuery(window).scroll(function () {
        if (jQuery(this).scrollTop() === 0) {
            jQuery(".tm-totop-scroller").addClass("totop-idden");
        } else {
            jQuery(".tm-totop-scroller").removeClass("totop-hidden");
        }
    });

});

